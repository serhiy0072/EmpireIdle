

using EmpireIdle.Domain.Entities;
using EmpireIdle.Domain.ValueObjects;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace EmpireIdle.Infrastructure.Persistence.Configurations
{
    /// <summary>
    /// EF Core конфігурація для PlayerWallet aggregate.
    /// </summary>
    public class PlayerWalletConfiguration : IEntityTypeConfiguration<PlayerWallet>
    {
        public void Configure(EntityTypeBuilder<PlayerWallet> builder)
        {
            builder.HasKey(pw => pw.Id);
            builder.Ignore(pw => pw.DomainEvents);

            builder.Property(pw => pw.GemBalance).HasConversion(g => g.Value, v => new GemAmount(v)).HasColumnName("GemBalance");
            builder.Property(pw => pw.UserId).IsRequired().HasMaxLength(450);
            builder.Property(pw => pw.UpdatedAt).IsRequired();

            builder.Property<uint>("Version").IsRowVersion();
            builder.HasIndex(pw => pw.UserId).IsUnique();
            builder.HasMany(pw => pw.Transactions).WithOne().HasForeignKey("WalletId").IsRequired();

            builder.Metadata.FindNavigation(nameof(PlayerWallet.Transactions))!.SetPropertyAccessMode(PropertyAccessMode.Field);
        }
    }
}
